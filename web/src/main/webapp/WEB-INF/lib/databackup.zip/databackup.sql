-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 25-02-28 15:51
-- 서버 버전: 5.1.72-log
-- PHP 버전: 5.2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `ckk_402`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `agree`
--

CREATE TABLE IF NOT EXISTS `agree` (
  `aid` char(20) NOT NULL,
  `aterm` enum('Y','') NOT NULL DEFAULT '',
  `acollect` enum('Y','') NOT NULL DEFAULT '',
  `ashare` enum('Y','') NOT NULL DEFAULT '',
  `adelegate` enum('Y','') NOT NULL DEFAULT '',
  `amarketing` enum('Y','') DEFAULT NULL,
  `adate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `aid` (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `agree`
--

INSERT INTO `agree` (`aid`, `aterm`, `acollect`, `ashare`, `adelegate`, `amarketing`, `adate`) VALUES
('test', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-07-02 16:24:44'),
('tester', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-07-03 03:49:18'),
('user', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-07-04 05:17:38'),
('tester1', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-07-04 05:23:49'),
('sad123', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-07-05 02:35:29'),
('tester2', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-07-24 05:14:29'),
('test12', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-10-14 05:29:35'),
('test123', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-10-15 05:01:38'),
('dan', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-10-15 05:04:15'),
('jyeony', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-10-15 05:57:01'),
('hana', 'Y', 'Y', 'Y', 'Y', 'Y', '2024-10-21 06:24:46');

-- --------------------------------------------------------

--
-- 테이블 구조 `pensionlist`
--

CREATE TABLE IF NOT EXISTS `pensionlist` (
  `pidx` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `ppension_name` varchar(50) NOT NULL,
  `proom_name` varchar(30) NOT NULL,
  `proom_info` varchar(30) NOT NULL,
  `pcount` int(2) NOT NULL,
  `pmax_count` int(2) NOT NULL,
  `pprice` int(8) NOT NULL,
  `pimg` varchar(50) NOT NULL,
  PRIMARY KEY (`pidx`),
  UNIQUE KEY `ppension_name` (`ppension_name`,`proom_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- 테이블의 덤프 데이터 `pensionlist`
--

INSERT INTO `pensionlist` (`pidx`, `ppension_name`, `proom_name`, `proom_info`, `pcount`, `pmax_count`, `pprice`, `pimg`) VALUES
(1, '[강원 평창군] 한화리조트 평창', '로즈힙 101호', '방1, 주방1, 욕실1, 거실1', 2, 3, 165600, './img/hotel_01.jpg'),
(2, '[강원 평창군] 한화리조트 평창', '튤립 102호', '방1, 주방1, 욕실1, 거실1', 2, 3, 165600, './img/hotel_01.jpg'),
(3, '[강원 평창군] 한화리조트 평창', '레몬 103호', '방2, 주방1, 욕실1, 스파1, 거실1', 4, 6, 210000, './img/hotel_01.jpg'),
(4, '[강원 평창군] 한화리조트 평창', '무궁화 104호', '방2, 주방1, 욕실1, 스파1, 거실1', 4, 6, 228000, './img/hotel_01.jpg'),
(5, '[강원 평창군] 한화리조트 평창', '해바라기 105호', '방3, 주방1, 욕실2, 수영장, 거실5', 6, 8, 350000, './img/hotel_01.jpg'),
(6, '[강원 평창군] 휘닉스 평창', '레드 101호', '방1, 주방1, 욕실1, 스파1, 거실1', 2, 3, 192000, './img/hotel_02.jpg'),
(7, '[강원 평창군] 휘닉스 평창', '오렌지 201호', '방1, 주방1, 욕실1, 스파1, 거실1', 2, 3, 192000, './img/hotel_02.jpg'),
(8, '[강원 평창군] 휘닉스 평창', '그린 301호', '방1, 주방1, 욕실1, 스파1, 거실1', 2, 3, 192000, './img/hotel_02.jpg'),
(9, '[강원 평창군] 휘닉스 평창', '퍼블 401호', '방2, 주방1, 욕실1, 스파1, 거실1', 4, 4, 230000, './img/hotel_02.jpg'),
(10, '[제주시] 한화리조트 제주', '디럭스 (원룸)', '방1, 주방1, 욕실1, 거실1', 2, 3, 165000, './img/hotel_03.jpg'),
(11, '[제주시] 한화리조트 제주', '디럭스 (투룸)', '방2, 주방1, 욕실1, 거실1', 4, 5, 250000, './img/hotel_03.jpg'),
(12, '[제주시] 한화리조트 제주', '스위트 (온돌형)', '방2, 주방1, 욕실1, 거실1', 4, 5, 280000, './img/hotel_03.jpg'),
(13, '[제주시] 한화리조트 제주', '스위트 (호텔형)', '방2, 주방1, 욕실2, 거실1', 4, 6, 290000, './img/hotel_03.jpg'),
(14, '[제주시] 한화리조트 제주', '플레티엄 A', '방3, 주방1, 욕실2, 거실1', 6, 8, 330000, './img/hotel_03.jpg'),
(15, '[제주시] 한화리조트 제주', '플레티엄 B', '방3, 주방1, 욕실2, 거실1', 6, 8, 330000, './img/hotel_03.jpg'),
(16, '[제주시] 금호제주 리조트', 'R동 로뎀커플-1', '방1, 주방1, 욕실1, 스파1, 거실1', 2, 3, 258000, './img/hotel_04.jpg'),
(17, '[제주시] 금호제주 리조트', 'R동 로뎀커플-2', '방1, 주방1, 욕실1, 스파1, 거실1', 2, 3, 258000, './img/hotel_04.jpg'),
(18, '[제주시] 금호제주 리조트', 'R동 로뎀커플-3', '방1, 주방1, 욕실1, 스파1, 거실1', 2, 3, 258000, './img/hotel_04.jpg'),
(19, '[제주시] 금호제주 리조트', 'B동-카페월풀A', '방2, 주방1, 욕실1, 스파1, 거실1', 4, 6, 360000, './img/hotel_04.jpg'),
(20, '[제주시] 금호제주 리조트', 'B동-카페월풀B', '방2, 주방1, 욕실1, 스파1, 거실1', 4, 6, 360000, './img/hotel_04.jpg'),
(36, '[경남 거제시] 소노캄 거제', '고래 다섯마리', '방2, 주방1, 욕실1, 수영장1, 거실1', 4, 6, 340000, './img/hotel_05.jpg'),
(35, '[경남 거제시] 소노캄 거제', '고래 네마리', '방2, 주방1, 욕실1, 수영장1, 거실1', 4, 6, 280000, './img/hotel_05.jpg'),
(34, '[경남 거제시] 소노캄 거제', '고래 세마리', '방1, 주방1, 욕실1, 수영장1, 거실1', 2, 4, 280000, './img/hotel_05.jpg'),
(33, '[경남 거제시] 소노캄 거제', '고래 두마리', '방1, 주방1, 욕실1, 거실1', 2, 4, 246000, './img/hotel_05.jpg'),
(32, '[경남 거제시] 소노캄 거제', '고래 한마리', '방1, 주방1, 욕실1, 거실1', 2, 4, 246000, './img/hotel_05.jpg'),
(27, '[충남 보령시] 보령베이스 리조트', 'A1 물소리가 들려온다', '방1, 주방1, 욕실1, 거실1', 2, 4, 200000, './img/hotel_06.jpg'),
(28, '[충남 보령시] 보령베이스 리조트', 'C1 쏟아진다 별이', '방1, 주방1, 욕실1, 거실1', 2, 4, 200000, './img/hotel_06.jpg'),
(29, '[충남 보령시] 보령베이스 리조트', 'C2 초록나무를 세다', '방1, 주방1, 욕실1, 거실1', 2, 4, 200000, './img/hotel_06.jpg'),
(30, '[충남 보령시] 보령베이스 리조트', 'C3 새소리모닝콜', '방1, 주방1, 욕실1, 거실1', 2, 4, 200000, './img/hotel_06.jpg'),
(31, '[충남 보령시] 보령베이스 리조트', 'C4 해는벌써서산에', '방2, 주방1, 욕실2, 수영장1, 거실1', 4, 6, 300000, './img/hotel_06.jpg'),
(37, '[경남 거제시] 소노캄 거제', '고래 여섯마리', '방3, 주방1, 욕실2, 수영장1, 거실1', 6, 8, 340000, './img/hotel_05.jpg');

-- --------------------------------------------------------

--
-- 테이블 구조 `qa`
--

CREATE TABLE IF NOT EXISTS `qa` (
  `qidx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qcategory` varchar(15) NOT NULL,
  `qname` char(50) NOT NULL,
  `qtel` char(11) NOT NULL,
  `qmail` varchar(100) NOT NULL,
  `qtitle` varchar(200) NOT NULL,
  `qtext` text NOT NULL,
  `qfile_url1` varchar(100) DEFAULT NULL,
  `qfile_name1` varchar(100) DEFAULT NULL,
  `qfile_url2` varchar(100) DEFAULT NULL,
  `qfile_name2` varchar(100) DEFAULT NULL,
  `qanswer` char(10) NOT NULL,
  `qindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`qidx`),
  KEY `qmail` (`qmail`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- 테이블의 덤프 데이터 `qa`
--

INSERT INTO `qa` (`qidx`, `qcategory`, `qname`, `qtel`, `qmail`, `qtitle`, `qtext`, `qfile_url1`, `qfile_name1`, `qfile_url2`, `qfile_name2`, `qanswer`, `qindate`) VALUES
(13, '시설문의', '홍길동', '01012345678', 'hong@nate.com', '수영장 이용', '수영장 이용시간이 어떻게 되나요?', ' ', ' ', '', '', '미답변', '2024-07-04 03:43:27'),
(14, '예약 및 취소', 'test1', '01012358437', 'test1@test.com', '날씨로 인하여 예약을 변경하고 싶습니다.', '장마로 인하여 예약을 연기하고 싶은데 추가 수수료가 발생할까요?', '', '', '', '', '미답변', '2024-07-04 05:00:52'),
(15, '환불 및 요금', 'tester', '01086257764', 'tester@tets.com', '당일 취소 환불 문의', '당일 취소는 전액 환불 가능한가요? 아니라면 수수료가 얼마인가요?', '', '', '', '', '답변완료', '2024-07-04 05:08:10'),
(16, '이용문의', 'tester', '01086257764', 'tester@tets.com', '우산 문의', '비오는 날에 호텔에서 우산을 빌릴 수 있나요?', '', '', '', '', '미답변', '2024-07-04 05:11:06'),
(19, '시설문의', 'tester', '01086257764', 'tester@tets.com', '헬스장 시설 문의', '헬스장 시설이 있나요?', './upload/20240704365.jpg', '2.jpg', './upload/202407041115.jpg', '3.jpg', '미답변', '2024-07-04 06:34:08'),
(18, '이용문의', 'tester', '01086257764', 'tester@tets.com', '조식 이용 시간 문의', '조식 이용 시간이 몇시까지 인가요?', './upload/20240704355.jpg', '2.jpg', ' ', ' ', '미답변', '2024-07-04 06:30:17'),
(20, '이용문의', 'tester', '01086257764', 'tester@tets.com', '연박시 청소문의', '연박을 하는 경우에 매일 청소를 해주시나요?', ' ', ' ', '', '', '미답변', '2024-07-04 07:41:12'),
(21, '이용문의', 'tester', '01086257764', 'tester@tets.com', '퇴실 문의', '퇴실 시간이 11시 맞나요?', ' ', ' ', '', '', '미답변', '2024-07-04 07:50:01'),
(22, '이용문의', 'test', '01011111111', 'test@test.com', 'test', 'test', '', '', '', '', '미답변', '2024-07-04 08:03:26'),
(23, '이용문의', 'tester', '01086257764', 'tester@tets.com', '퇴실문의', '퇴실시간 관련해서 문의드립니다.', '', '', '', '', '미답변', '2024-07-24 04:58:50'),
(24, '시설문의', '김지현', '01099495075', 'kim507584@naver.com', '수영장 문의', '수영장 이용시간이 어떻게 되나요?', '', '', '', '', '답변완료', '2024-10-15 06:06:15'),
(26, '시설문의', '김단희', '01099990000', 'dan@naver.com', '수영장 문의', '수영장 운영시간이 어떻게 되나요?', '/upload/202410291118.png', 'header_logo (1).png', '', '', '답변완료', '2024-10-29 01:55:09');

-- --------------------------------------------------------

--
-- 테이블 구조 `qa_answer`
--

CREATE TABLE IF NOT EXISTS `qa_answer` (
  `aidx` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qidx` int(10) NOT NULL,
  `atext` text NOT NULL,
  `aindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`aidx`),
  UNIQUE KEY `qidx` (`qidx`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 테이블의 덤프 데이터 `qa_answer`
--

INSERT INTO `qa_answer` (`aidx`, `qidx`, `atext`, `aindate`) VALUES
(1, 1, '퇴실 시간은 오전 11시 입니다.', '2024-07-03 05:30:40'),
(2, 2, '질문하신 내용을 확인 하였습니다.\r\n해당 당일건에 대해서는 100% 환불은 어렵습니다.\r\n단, 최소 50%까지 환불은 진행이 가능하므로, 양해 부탁 드립니다.\r\n감사합니다.', '2024-07-03 05:50:30'),
(3, 3, '\r\n질문하신 내용을 확인 하였습니다.\r\n해당 당일건에 대해서는 100% 환불은 어렵습니다.\r\n단, 최소 50%까지 환불은 진행이 가능하므로, 양해 부탁 드립니다.\r\n감사합니다.\r\n\r\n질문하신 내용을 확인 하였습니다.\r\n해당 당일건에 대해서는 100% 환불은 어렵습니다.\r\n단, 최소 50%까지 환불은 진행이 가능하므로, 양해 부탁 드립니다.\r\n감사합니다.\r\n\r\n질문하신 내용을 확인 하였습니다.\r\n해당 당일건에 대해서는 100% 환불은 어렵습니다.\r\n단, 최소 50%까지 환불은 진행이 가능하므로, 양해 부탁 드립니다.\r\n감사합니다.', '2024-07-03 06:05:56'),
(4, 15, '예약 당일에 취소하시면 전액 환불 가능합니다.\r\n감사합니다.', '2024-07-04 05:12:26'),
(5, 24, 'test', '2024-10-15 06:07:58'),
(6, 26, '오전 10시부터 오후 8까지 이용가능합니다.', '2024-10-29 06:17:02');

-- --------------------------------------------------------

--
-- 테이블 구조 `reservation`
--

CREATE TABLE IF NOT EXISTS `reservation` (
  `ridx` int(9) unsigned NOT NULL AUTO_INCREMENT,
  `ruser_id` varchar(20) NOT NULL,
  `rpension_name` varchar(50) NOT NULL,
  `rroom` varchar(30) NOT NULL,
  `rdatechoice` varchar(20) NOT NULL,
  `rroom_info` varchar(30) NOT NULL,
  `rmember` char(10) NOT NULL,
  `radd_member` int(2) NOT NULL,
  `rprice` int(8) NOT NULL,
  `ruser_name` char(20) NOT NULL,
  `ruser_hp` char(11) NOT NULL,
  `ruser_member` int(2) NOT NULL,
  `ruser_email` varchar(30) NOT NULL,
  `renter_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ridx`),
  KEY `rpension_name` (`rpension_name`,`rroom`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- 테이블의 덤프 데이터 `reservation`
--

INSERT INTO `reservation` (`ridx`, `ruser_id`, `rpension_name`, `rroom`, `rdatechoice`, `rroom_info`, `rmember`, `radd_member`, `rprice`, `ruser_name`, `ruser_hp`, `ruser_member`, `ruser_email`, `renter_date`) VALUES
(1, '', '[강원 평창군] 휘닉스 평창', '그린 301호', '', '방2, 주방1, 욕실1, 스파1, 거실1', '4', 4, 230000, '', '', 4, '', '2024-07-04 06:33:48'),
(2, '', '[강원 평창군] 휘닉스 평창', '그린 301호', '2024-07-11 15:37', '방1, 주방1, 욕실1, 스파1, 거실1', '2', 3, 192000, '김유신', '0101231231', 2, 'hu@gmail.com', '2024-07-04 06:37:53'),
(3, '', '[제주시] 금호제주 리조트', 'B동-카페월풀A', '2024-07-17', '방1, 주방1, 욕실1, 스파1, 거실1', '2', 3, 258000, '홍길동', '01055555555', 2, 'hong@naver.com', '2024-07-04 06:38:33'),
(4, 'ruser_id', '[제주시] 한화리조트 제주', '디럭스 (원룸)', '2024-07-09', '방2, 주방1, 욕실1, 거실1', '4', 5, 280000, '강감찬', '01012312344', 4, 'hu@gmail.com', '2024-07-04 06:40:56'),
(5, 'tester', '[강원 평창군] 휘닉스 평창', '그린 301호', '2024-07-05', '방1, 주방1, 욕실1, 스파1, 거실1', '2', 3, 192000, '강감찬', '123345', 2, '1', '2024-07-04 06:41:53'),
(6, 'tester', '[제주시] 한화리조트 제주', '디럭스 (원룸)', '', '방2, 주방1, 욕실1, 거실1', '4', 5, 280000, '', '', 4, '', '2024-07-04 07:17:32'),
(7, 'tester', '[제주시] 한화리조트 제주', '스위트 (온돌형)', '2024-07-09', '방2, 주방1, 욕실1, 거실1', '4', 5, 280000, '홍길동', '010101010', 4, 'hong@naver.com', '2024-07-04 07:56:41'),
(8, 'tester', '[강원 평창군] 한화리조트 평창', '튤립 102호', '2024-07-24', '방1, 주방1, 욕실1, 거실1', '2', 3, 165600, '홍길동', '01012345678', 2, 'hong@naver.com', '2024-07-04 08:10:07'),
(9, 'null', '[강원 평창군] 한화리조트 평창', '로즈힙 101호', '2024-07-10', '방1, 주방1, 욕실1, 거실1', '2', 3, 165600, '홍길동', '01012345678', 2, 'jjsadsad', '2024-07-05 02:20:05'),
(10, 'null', '[강원 평창군] 한화리조트 평창', '무궁화 104호', '2024-07-17', '방2, 주방1, 욕실1, 스파1, 거실1', '4', 6, 228000, '김단희', '01091192222', 4, 'eksgml22@naver.com', '2024-07-05 08:51:51'),
(11, 'null', '[충남 보령시] 보령베이스 리조트', 'C1 쏟아진다 별이', '2024-07-23', '방1, 주방1, 욕실1, 거실1', '2', 4, 200000, '홍길동', '01012345678', 2, 'hong@naver.com', '2024-07-24 03:21:07'),
(12, 'tester', '[제주시] 한화리조트 제주', '디럭스 (투룸)', '2024-10-17', '방2, 주방1, 욕실1, 거실1', '4', 5, 250000, '최연욱', '01012364567', 4, 'hong@naver.com', '2024-10-11 04:59:04'),
(13, 'test12', '[강원 평창군] 휘닉스 평창', '오렌지 201호', '2024-10-24', '방1, 주방1, 욕실1, 스파1, 거실1', '2', 3, 192000, '네네치킨', '01043431234', 2, 'sdfsdfsfa@asdf.com', '2024-10-14 05:31:01'),
(14, 'null', '[강원 평창군] 한화리조트 평창', '무궁화 104호', '2024-10-17', '방2, 주방1, 욕실1, 스파1, 거실1', '4', 6, 228000, '홍길동', '01012345678', 4, 'hong@naver.com', '2024-10-15 01:39:07'),
(15, 'null', '[제주시] 한화리조트 제주', '디럭스 (투룸)', '2024-10-24', '방2, 주방1, 욕실1, 거실1', '4', 5, 250000, '김단희', '01013459474', 4, 'pesnsiso@amdjdp', '2024-10-18 08:15:16'),
(16, 'null', '[강원 평창군] 한화리조트 평창', '로즈힙 101호', '2025-02-03', '방1, 주방1, 욕실1, 거실1', '2', 3, 165600, '김민', '01088121234', 2, '123@123.com', '2025-02-05 01:43:11');

-- --------------------------------------------------------

--
-- 테이블 구조 `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `uno` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` char(20) NOT NULL,
  `uname` char(50) NOT NULL,
  `upass` varchar(150) NOT NULL,
  `umail` varchar(100) NOT NULL,
  `utel` varchar(15) NOT NULL,
  `udate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uno`),
  UNIQUE KEY `id` (`uid`),
  UNIQUE KEY `tel` (`utel`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- 테이블의 덤프 데이터 `user_info`
--

INSERT INTO `user_info` (`uno`, `uid`, `uname`, `upass`, `umail`, `utel`, `udate`) VALUES
(1, 'test', 'test', 'a1234', 'test@test.com', '01011111111', '2024-07-02 16:24:00'),
(2, 'hong', '홍길동', 'a1234', 'hong@nate.com', '01012345678', '2024-07-03 02:40:28'),
(3, 'test1', 'test1', '1234', 'test1@test.com', '01012358437', '2024-07-03 03:24:07'),
(4, 'test2', 'test2', '1234', 'test2@test.com', '01023878234', '2024-07-03 03:34:47'),
(5, 'gang', '강감찬', 'a1234', 'gang@naver.com', '01077652658', '2024-07-03 03:36:36'),
(6, 'gang1', '강감찬1', 'a1234', 'gang1@naver.com', '01077652657', '2024-07-03 03:39:15'),
(8, 'tester', 'tester', '1234', 'tester@tets.com', '01086257764', '2024-07-03 03:49:18'),
(9, 'user', 'user', '1234', 'kkk@naver.com', '01011112222', '2024-07-04 05:17:38'),
(10, 'tester1', 'tester1', '1234', 'tester1@test.com', '01092748372', '2024-07-04 05:23:49'),
(11, 'sad123', 'asdas', '1234', 'asdasd@asdsad.com', '01011111112', '2024-07-05 02:35:29'),
(12, 'tester2', 'tester2', '1234', 'tester2@nate.net', '01032328877', '2024-07-24 05:14:29'),
(13, 'test12', 'asdasd', 'test1234', 'asdasd@hanmail.net', '01084583232', '2024-10-14 05:29:35'),
(14, 'test123', 'test1234', 'test1234', 'asjdhkajsd@asjdfasdf.com', '01032824352', '2024-10-15 05:01:38'),
(15, 'dan', '김단희', 'dandan1234', 'dan@naver.com', '01099990000', '2024-10-15 05:04:15'),
(16, 'jyeony', '김지현', 'wlgus', 'kim507584@naver.com', '01099495075', '2024-10-15 05:57:01'),
(17, 'hana', '김하나', 'hana1234', 'hana@gmail.com', '01012341234', '2024-10-21 06:24:45');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
